﻿using System.Data;
using System.Runtime.CompilerServices;

namespace VectorCalculatorTemplate.ConApp
{
    public class Vector
    {
        #region fields
        private int _columns;
        private double[] _values;
        private bool _isZeroVector;
        private double _amount;
        private double result;
        #endregion fields

        #region constructors

        public Vector (params double[] values)
        {
            _values = values;
            _columns = Columns;
            GetValue(_columns);
        }

        #endregion constructors

        #region properties
        public int Columns { get { return _values.Length; } }
        public double[] Values 
        { 
            get 
            {
                return _values;
            } 
        }
        public bool IsZeroVector 
        { 
            get 
            { 
                for (int i = 0; i < _values.Length; i++)
                {
                    if (_values[i] == 0)
                    {
                        return true;
                    }
                    if (_values[i] >= 1)
                    {
                        return false;
                    }
                }

                return _isZeroVector;
            } 
        }
        public double Amount 
        { 
            get 
            {
                for (int i = 0; i < _values.Length; i++)
                {
                    return _amount = Math.Sqrt((_values[0] * _values[0]) + _values[1] * _values[1]);
                }

                return _amount;
            } 
        }
        #endregion properties

        #region methods

        public int GetValue(double columns)
        {
            for (int i = 0; i < _values.Length; i++)
            {
                if (columns == i)
                {
                    return  Convert.ToInt32(_values[i]);
                }
            }

            return -1;
        }

        public string ToString()
        {
            if (_values.Length > 0)
            {
                return $"[ {_values[0]} {_values[1]} {_values[2]} ]";
            }
            
            return $"[  ]";

        }

        #endregion methods

        #region operators

        public static Vector operator + (Vector lhs, Vector rhs) 
        { 
            throw new NotImplementedException();
        }

        public static Vector operator - (Vector lhs, Vector rhs) 
        { 
            throw new NotImplementedException ();
        }

        public static Vector operator * (Vector lhs, Vector rhs)
        {
            throw new NotImplementedException();
        }

        public static Vector operator * (double scalar, Vector rhs)
        {
            throw new NotImplementedException();
        }

        public static Vector operator * (Vector lhs, double scalar)
        {
            throw new NotImplementedException();
        }
        #endregion operators
    }
}
