# POSE

## Vector Calculator

Lehrziele:

- Lesen von Unit-Tests
- Eigenschaften, Methoden und Operationen aus den Unit-Tests ermitteln
- Erstellen von Konstruktoren
- Erstellen von Eigenschaften
- Erstellen von Methoden
- Überladen von Operatoren

### Aufgabenstellung

Erstellen Sie die Klasse **Vector** auf Basis der beigefügten Unit-Tests. Sie dürfen die Unit-Tests auf keinen Fall verändern. Entwickeln Sie zu Beginn die Schnittstelle (Eigenschaften, Konstruktoren, Methoden und Operatoren) der Klasse und definieren Sie die Members mit ***throw new NotImplementedException()***. Wenn die Schnittstelle richtig definiert ist, dann ist das Projekt fehlerfrei Kompilierbar. Im Anschluß setzen Sie die Definition der Members Schritt für Schritt um, solange bis alle Unit-Tests erfolgreich ausgeführt werden können.

#### Bereich **Felder**

Im Bereich *fields* sollen Sie alle Felder definieren, welches Sie für die Umstezung der Klasse benötigen. Beachten Sie, dass alle Felder mit der Sichtbarkeit ***private*** ausgeführt sein müssen.

#### Bereich **Eigenschaften**

Im Bereich ***properties*** werden alle Eigenschaften aus dem Unit-Tests aufgeführt. Achten Sie bitte darauf, dass die Schnittstelle nur den Zugriff im Unit-Test erfüllt. Das bedeuted, dass eine Eigenschaft nur als lesend definiert wird, wenn die Unit-Tests nur lesend auf diese Eigenschaft zugreifen (also nicht schreibend!).

```csharp
* Columns       // Liefert die Anzahl der Spalten
* Values        // Lifert die Werte aus dem Vektor. 
                // Beachte, dass die Werte im Vektor unveränderlich sind!
* IsZeroVector  // Zeigt an, dass der Vector ein Null-Vektor ist
* Amount        // Berechnet den Betrag des Vektors (die Würzel der Summer aller quadrierten Werte)                 
```

#### Bereich **Methoden**

Im Bereich der ***methods*** werden alle Methoden der Kklasse definiert. Achten Sie darauf, dass die Methoden nur die Schnittstelle erfüllen. Das bedeutet, dass die Methoden nur die Rückgabe liefern, welche im Unit-Test erwartet wird. Die Methoden dürfen keine Seiteneffekte haben.

```csharp
* GetValue(...) // Liefert den Wert an der Position.
                // Ist der Index außerhalb des Vektors, dann wird eine
                // IndexOutOfRangeException geworfen.
* ToSTring()    // Liefert den Vektor als Zeichenkette ([ v1, v2, v3 ]).
```

#### Bereich **Operatoren**

Im Bereich der ***operators*** werden die Operatoren definiert. Die Operatoren sind auf den Typ ***Vector*** bezogen und dürfen die Operanden nicht ändern. Die Operatoren dürfen keine Seiteneffekte haben.

```csharp
* operator +    // Addiert zwei Vektoren mit folgender Voraussetzung:
                // Die Anzahl der Spalten muss identisch sein.
                // [ v1, v2, v3 ] + [ w1, w2, w3 ] = [ v1 + w1, v2 + w2, v3 + w3 ]
* operator -    // Subtrahiert zwei Vektoren mit folgender Voraussetzung:
                // Die Anzahl der Spalten muss identisch sein.
                // [ v1, v2, v3 ] - [ w1, w2, w3 ] = [ v1 - w1, v2 - w2, v3 - w3 ]
* operator *    // Multipliziert einen Vektor mit einem Skalar.
                // [ v1, v2, v3 ] * 2 = [ v1 * 2, v2 * 2, v3 * 2 ]
* operator *    // Multipliziert einem Skalar mit einem Vektor.
                // 2 * [ v1, v2, v3 ] = [ 2 * v1, 2 * v2, 2 * v3 ]
```

**Hinweis:** Sie müssen alle öffentlichen Methoden, Eigenschaften und Operatoren dokumentieren.

Viel Glück!
