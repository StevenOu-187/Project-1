﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace VectorCalculatorTemplate.ConApp.UnitTests
{
    [TestClass]
    public class VectorTests
    {
        /// <summary>
        /// Testet den Konstruktor, um sicherzustellen, dass die Werte korrekt initialisiert werden.
        /// Die Uebergabe der Werte erfolgt als Array.
        /// </summary>
        [TestMethod]
        public void Constructor_ShouldInitializeValues()
        {
            // Arrange
            double[] values = { 1.0, 2.0, 3.0 };

            // Act
            Vector vector = new Vector(values);

            // Assert
            CollectionAssert.AreEqual(values, vector.Values);
        }

        /// <summary>
        /// Testet den Konstruktor, um sicherzustellen, dass die Werte korrekt initialisiert werden.
        /// Die Uebergabe der Werte erfolgt als Liste von Argumenten.
        /// </summary>
        [TestMethod]
        public void Constructor_ShouldInitializeValues02()
        {
            // Act
            Vector vector = new Vector(1.0, 2.0, 3.0);

            // Assert
            CollectionAssert.AreEqual(new double[] { 1.0, 2.0, 3.0 }, vector.Values);
        }

        /// <summary>
        /// Testet den Konstruktor, um sicherzustellen, dass die Werte korrekt initialisiert werden.
        /// Die Uebergabe der Werte erfolgt als Liste von Argumenten.
        /// </summary>
        [TestMethod]
        public void Constructor_ShouldInitializeValues03()
        {
            // Act
            Vector vector = new Vector(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0);

            // Assert
            CollectionAssert.AreEqual(new double[] { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0 }, vector.Values);
        }

        /// <summary>
        /// Testet die Columns-Eigenschaft, um sicherzustellen, dass die Anzahl der Spalten korrekt zurückgegeben wird.
        /// Die Uebergabe der Werte erfolgt als Liste von Argumenten.
        /// </summary>
        [TestMethod]
        public void Columns_ShouldReturnCorrectNumberOfColumns02()
        {
            // Arrange
            Vector vector = new Vector(1.0, 2.0, 3.0);

            // Act
            int columns = vector.Columns;

            // Assert
            Assert.AreEqual(3, columns);
        }

        /// <summary>
        /// Testet die Columns-Eigenschaft, um sicherzustellen, dass die Anzahl der Spalten korrekt zurückgegeben wird.
        /// Die Uebergabe der Werte erfolgt als Array.
        /// </summary>
        [TestMethod]
        public void Columns_ShouldReturnCorrectNumberOfColumns()
        {
            // Arrange
            double[] values = { 1.0, 2.0, 3.0 };
            Vector vector = new Vector(values);

            // Act
            int columns = vector.Columns;

            // Assert
            Assert.AreEqual(3, columns);
        }

        /// <summary>
        /// Testet die IsZeroVector-Eigenschaft, um sicherzustellen, dass ein Nullvektor korrekt erkannt wird.
        /// </summary>
        [TestMethod]
        public void IsZeroVector_ShouldReturnTrueForZeroVector()
        {
            // Arrange
            double[] values = { 0.0, 0.0, 0.0 };
            Vector vector = new Vector(values);

            // Act
            bool isZeroVector = vector.IsZeroVector;

            // Assert
            Assert.IsTrue(isZeroVector);
        }

        /// <summary>
        /// Testet die IsZeroVector-Eigenschaft, um sicherzustellen, dass ein Nicht-Nullvektor korrekt erkannt wird.
        /// </summary>
        [TestMethod]
        public void IsZeroVector_ShouldReturnFalseForNonZeroVector()
        {
            // Arrange
            double[] values = { 1.0, 0.0, 0.0 };
            Vector vector = new Vector(values);

            // Act
            bool isZeroVector = vector.IsZeroVector;

            // Assert
            Assert.IsFalse(isZeroVector);
        }

        /// <summary>
        /// Testet die GetValue-Methode, um sicherzustellen, dass eine IndexOutOfRangeException für ungültige Indizes geworfen wird.
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void GetValue_ShouldThrowExceptionForInvalidIndex()
        {
            // Arrange
            double[] values = { 1.0, 2.0, 3.0 };
            Vector vector = new Vector(values);

            // Act
            vector.GetValue(-1);
        }

        /// <summary>
        /// Testet die GetValue-Methode, um sicherzustellen, dass der korrekte Wert zurückgegeben wird.
        /// </summary>
        [TestMethod]
        public void GetValue_ShouldReturnCorrectValue()
        {
            // Arrange
            double[] values = { 1.0, 2.0, 3.0 };
            Vector vector = new Vector(values);

            // Act
            double value = vector.GetValue(1);

            // Assert
            Assert.AreEqual(2.0, value);
        }

        /// <summary>
        /// Testet den Additionsoperator, um sicherzustellen, dass zwei Vektoren korrekt addiert werden.
        /// </summary>
        [TestMethod]
        public void OperatorAddition_ShouldAddVectorsCorrectly()
        {
            // Arrange
            Vector v1 = new Vector(1.0, 2.0, 3.0);
            Vector v2 = new Vector(4.0, 5.0, 6.0);

            // Act
            Vector result = v1 + v2;

            // Assert
            double[] expectedValues = { 5.0, 7.0, 9.0 };
            CollectionAssert.AreEqual(expectedValues, result.Values);
        }

        /// <summary>
        /// Testet den Additionsoperator, um sicherzustellen, dass eine InvalidOperationException für Vektoren unterschiedlicher Größe geworfen wird.
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void OperatorAddition_ShouldThrowExceptionForDifferentSizedVectors()
        {
            // Arrange
            Vector v1 = new Vector(1.0, 2.0);
            Vector v2 = new Vector(3.0, 4.0, 5.0);

            // Act
            //Vector result = v1 + v2;
        }

        /// <summary>
        /// Testet den Subtraktionsoperator, um sicherzustellen, dass zwei Vektoren korrekt subtrahiert werden.
        /// </summary>
        [TestMethod]
        public void OperatorSubtraction_ShouldSubtractVectorsCorrectly()
        {
            // Arrange
            Vector v1 = new Vector(4.0, 5.0, 6.0);
            Vector v2 = new Vector(1.0, 2.0, 3.0);

            // Act
            Vector result = v1 - v2;

            // Assert
            double[] expectedValues = { 3.0, 3.0, 3.0 };
            CollectionAssert.AreEqual(expectedValues, result.Values);
        }

        /// <summary>
        /// Testet den Subtraktionsoperator, um sicherzustellen, dass eine InvalidOperationException für Vektoren unterschiedlicher Größe geworfen wird.
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void OperatorSubtraction_ShouldThrowExceptionForDifferentSizedVectors()
        {
            // Arrange
            Vector v1 = new Vector(1.0, 2.0);
            Vector v2 = new Vector(3.0, 4.0, 5.0);

            // Act
            Vector result = v1 - v2;
        }

        /// <summary>
        /// Testet, dass Änderungen an dem Array, das zur Konstruktion des Vektors verwendet wird, den Vektor nicht beeinflussen.
        /// </summary>
        [TestMethod]
        public void Constructor_ShouldCreateImmutableVector()
        {
            // Arrange
            double[] values = { 1.0, 2.0, 3.0 };
            Vector vector = new Vector(values);

            // Act
            values[0] = 10.0;

            // Assert
            double[] expectedValues = { 1.0, 2.0, 3.0 };
            CollectionAssert.AreEqual(expectedValues, vector.Values);
        }

        /// <summary>
        /// Testet, dass Änderungen an dem von der Values-Eigenschaft zurückgegebenen Array den Vektor nicht beeinflussen.
        /// </summary>
        [TestMethod]
        public void Values_ShouldReturnImmutableArray()
        {
            // Arrange
            double[] values = { 1.0, 2.0, 3.0 };
            Vector vector = new Vector(values);
            double[] returnedValues = vector.Values;

            // Act
            returnedValues[0] = 10.0;

            // Assert
            double[] expectedValues = { 1.0, 2.0, 3.0 };
            CollectionAssert.AreEqual(expectedValues, vector.Values);
        }

        /// <summary>
        /// Testet, dass der Additionsoperator unveränderliche Vektoren erzeugt.
        /// </summary>
        [TestMethod]
        public void OperatorAddition_ShouldCreateImmutableResult()
        {
            // Arrange
            Vector v1 = new Vector(1.0, 2.0, 3.0);
            Vector v2 = new Vector(4.0, 5.0, 6.0);
            Vector result = v1 + v2;

            // Act
            double[] resultValues = result.Values;
            resultValues[0] = 10.0;

            // Assert
            double[] expectedValues = { 5.0, 7.0, 9.0 };
            CollectionAssert.AreEqual(expectedValues, result.Values);
        }

        /// <summary>
        /// Testet, dass der Subtraktionsoperator unveränderliche Vektoren erzeugt.
        /// </summary>
        [TestMethod]
        public void OperatorSubtraction_ShouldCreateImmutableResult()
        {
            // Arrange
            Vector v1 = new Vector(4.0, 5.0, 6.0);
            Vector v2 = new Vector(1.0, 2.0, 3.0);
            Vector result = v1 - v2;

            // Act
            double[] resultValues = result.Values;
            resultValues[0] = 10.0;

            // Assert
            double[] expectedValues = { 3.0, 3.0, 3.0 };
            CollectionAssert.AreEqual(expectedValues, result.Values);
        }

        /// <summary>
        /// Testet den Multiplikationsoperator, um sicherzustellen, dass ein Vektor korrekt mit einem Skalar multipliziert wird.
        /// </summary>
        [TestMethod]
        public void OperatorScalarMultiplication_VectorTimesScalar_ShouldMultiplyCorrectly()
        {
            // Arrange
            Vector vector = new Vector(1.0, 2.0, 3.0);
            double scalar = 2.0;

            // Act
            Vector result = vector * scalar;

            // Assert
            double[] expectedValues = { 2.0, 4.0, 6.0 };
            CollectionAssert.AreEqual(expectedValues, result.Values);
        }

        /// <summary>
        /// Testet den Multiplikationsoperator, um sicherzustellen, dass ein Skalar korrekt mit einem Vektor multipliziert wird.
        /// </summary>
        [TestMethod]
        public void OperatorScalarMultiplication_ScalarTimesVector_ShouldMultiplyCorrectly()
        {
            // Arrange
            Vector vector = new Vector(1.0, 2.0, 3.0);
            double scalar = 2.0;

            // Act
            Vector result = scalar * vector;

            // Assert
            double[] expectedValues = { 2.0, 4.0, 6.0 };
            CollectionAssert.AreEqual(expectedValues, result.Values);
        }

        /// <summary>
        /// Testet den Multiplikationsoperator, um sicherzustellen, dass die Multiplikation eines Vektors mit Null einen Nullvektor ergibt.
        /// </summary>
        [TestMethod]
        public void OperatorScalarMultiplication_VectorTimesZero_ShouldReturnZeroVector()
        {
            // Arrange
            Vector vector = new Vector(1.0, 2.0, 3.0);
            double scalar = 0.0;

            // Act
            Vector result = vector * scalar;

            // Assert
            double[] expectedValues = { 0.0, 0.0, 0.0 };
            CollectionAssert.AreEqual(expectedValues, result.Values);
        }

        /// <summary>
        /// Testet den Multiplikationsoperator, um sicherzustellen, dass die Multiplikation eines Nullvektors mit einem Skalar einen Nullvektor ergibt.
        /// </summary>
        [TestMethod]
        public void OperatorScalarMultiplication_ZeroVectorTimesScalar_ShouldReturnZeroVector()
        {
            // Arrange
            Vector vector = new Vector(0.0, 0.0, 0.0);
            double scalar = 5.0;

            // Act
            Vector result = vector * scalar;

            // Assert
            double[] expectedValues = { 0.0, 0.0, 0.0 };
            CollectionAssert.AreEqual(expectedValues, result.Values);
        }

        /// <summary>
        /// Testet den Multiplikationsoperator, um sicherzustellen, dass der resultierende Vektor unveränderlich ist.
        /// </summary>
        [TestMethod]
        public void OperatorScalarMultiplication_ShouldCreateImmutableResult()
        {
            // Arrange
            Vector vector = new Vector(1.0, 2.0, 3.0);
            double scalar = 2.0;
            Vector result = vector * scalar;

            // Act
            double[] resultValues = result.Values;
            resultValues[0] = 10.0;

            // Assert
            double[] expectedValues = { 2.0, 4.0, 6.0 };
            CollectionAssert.AreEqual(expectedValues, result.Values);
        }

        /// <summary>
        /// Testet die Amount-Eigenschaft, um sicherzustellen, dass der Betrag eines Vektors korrekt berechnet wird.
        /// </summary>
        [TestMethod]
        public void Amount_ShouldReturnCorrectMagnitude()
        {
            // Arrange
            Vector vector = new Vector(3.0, 4.0);

            // Act
            double amount = vector.Amount;

            // Assert
            double expectedAmount = 5.0; // sqrt(3^2 + 4^2) = 5
            Assert.AreEqual(expectedAmount, amount);
        }

        /// <summary>
        /// Testet die Amount-Eigenschaft, um sicherzustellen, dass der Betrag eines Nullvektors Null ist.
        /// </summary>
        [TestMethod]
        public void Amount_ShouldReturnZeroForZeroVector()
        {
            // Arrange
            Vector vector = new Vector(0.0, 0.0, 0.0);

            // Act
            double amount = vector.Amount;

            // Assert
            double expectedAmount = 0.0;
            Assert.AreEqual(expectedAmount, amount);
        }

        /// <summary>
        /// Testet die Amount-Eigenschaft, um sicherzustellen, dass der Betrag korrekt für einen Vektor mit negativen Werten berechnet wird.
        /// </summary>
        [TestMethod]
        public void Amount_ShouldReturnCorrectMagnitudeForNegativeValues()
        {
            // Arrange
            Vector vector = new Vector(-3.0, -4.0);

            // Act
            double amount = vector.Amount;

            // Assert
            double expectedAmount = 5.0; // sqrt((-3)^2 + (-4)^2) = 5
            Assert.AreEqual(expectedAmount, amount);
        }

        /// <summary>
        /// Testet die Amount-Eigenschaft, um sicherzustellen, dass der Betrag korrekt für einen Vektor mit gemischten positiven und negativen Werten berechnet wird.
        /// </summary>
        [TestMethod]
        public void Amount_ShouldReturnCorrectMagnitudeForMixedValues()
        {
            // Arrange
            Vector vector = new Vector(-3.0, 4.0);

            // Act
            double amount = vector.Amount;

            // Assert
            double expectedAmount = 5.0; // sqrt((-3)^2 + 4^2) = 5
            Assert.AreEqual(expectedAmount, amount);
        }

        /// <summary>
        /// Testet die Amount-Eigenschaft, um sicherzustellen, dass der Betrag korrekt für einen Vektor mit mehr als zwei Dimensionen berechnet wird.
        /// </summary>
        [TestMethod]
        public void Amount_ShouldReturnCorrectMagnitudeForHigherDimensions()
        {
            // Arrange
            Vector vector = new Vector(1.0, 2.0, 2.0);

            // Act
            double amount = vector.Amount;

            // Assert
            double expectedAmount = 3.0; // sqrt(1^2 + 2^2 + 2^2) = 3
            Assert.AreEqual(expectedAmount, amount);
        }
        /// <summary>
        /// Testet die ToString-Methode, um sicherzustellen, dass die Zeichenfolgendarstellung eines Vektors korrekt formatiert ist.
        /// </summary>
        [TestMethod]
        public void ToString_ShouldReturnCorrectFormat()
        {
            // Arrange
            Vector vector = new Vector(1.0, 2.0, 3.0);

            // Act
            string result = vector.ToString();

            // Assert
            string expected = "[ 1 2 3 ]";
            Assert.AreEqual(expected, result);
        }

        /// <summary>
        /// Testet die ToString-Methode, um sicherzustellen, dass die Zeichenfolgendarstellung eines Nullvektors korrekt formatiert ist.
        /// </summary>
        [TestMethod]
        public void ToString_ShouldReturnCorrectFormatForZeroVector()
        {
            // Arrange
            Vector vector = new Vector(0.0, 0.0, 0.0);

            // Act
            string result = vector.ToString();

            // Assert
            string expected = "[ 0 0 0 ]";
            Assert.AreEqual(expected, result);
        }

        /// <summary>
        /// Testet die ToString-Methode, um sicherzustellen, dass die Zeichenfolgendarstellung eines Vektors mit negativen Werten korrekt formatiert ist.
        /// </summary>
        [TestMethod]
        public void ToString_ShouldReturnCorrectFormatForNegativeValues()
        {
            // Arrange
            Vector vector = new Vector(-1.0, -2.0, -3.0);

            // Act
            string result = vector.ToString();

            // Assert
            string expected = "[ -1 -2 -3 ]";
            Assert.AreEqual(expected, result);
        }

        /// <summary>
        /// Testet die ToString-Methode, um sicherzustellen, dass die Zeichenfolgendarstellung eines gemischten Vektors korrekt formatiert ist.
        /// </summary>
        [TestMethod]
        public void ToString_ShouldReturnCorrectFormatForMixedValues()
        {
            // Arrange
            Vector vector = new Vector(1.0, -2.0, 3.0);

            // Act
            string result = vector.ToString();

            // Assert
            string expected = "[ 1 -2 3 ]";
            Assert.AreEqual(expected, result);
        }

        /// <summary>
        /// Testet die ToString-Methode, um sicherzustellen, dass die Zeichenfolgendarstellung eines leeren Vektors korrekt formatiert ist.
        /// </summary>
        [TestMethod]
        public void ToString_ShouldReturnCorrectFormatForEmptyVector()
        {
            // Arrange
            Vector vector = new Vector();

            // Act
            string result = vector.ToString();

            // Assert
            string expected = "[  ]";
            Assert.AreEqual(expected, result);
        }
    }
}
